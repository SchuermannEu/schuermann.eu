package ldap

import gldapo.schema.annotation.GldapoNamingAttribute
import gldapo.schema.annotation.GldapoSynonymFor

/** 
 * LDAP User Domain class 
 * Represents the user from LDAP directory
 *
 * @author Dominik Schuermann
 */
class LdapUser {

  /** "Primary Key" */
	@GldapoNamingAttribute
  @GldapoSynonymFor("uid")
	String username

  String cn

  @GldapoSynonymFor("sn")
  String lastname

  @GldapoSynonymFor("givenName")
  String firstname

  @GldapoSynonymFor("mail")
  String email

  @GldapoSynonymFor("ou")
  String ldapRole

}
