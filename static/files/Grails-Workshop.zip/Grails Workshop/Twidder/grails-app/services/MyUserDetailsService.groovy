import twidder.User
import org.springframework.security.core.authority.GrantedAuthorityImpl
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService

import org.codehaus.groovy.grails.plugins.springsecurity.GrailsUserDetailsService
import org.codehaus.groovy.grails.plugins.springsecurity.GrailsUser
import org.springframework.security.core.userdetails.UsernameNotFoundException

/**
 * Service that is used instead of GormUserDetailsService from Spring Security Plugin
 * It overrides in conf/spring/resources.groovy the Spring class
 *
 * It is used in conjunction with the Ldap Plugin to create Users from Ldap when they are not
 * in the local database
 *
 * @author Dominik Schuermann
 */
class MyUserDetailsService implements GrailsUserDetailsService {
  
  UserDetails loadUserByUsername(String username, boolean loadRoles) throws UsernameNotFoundException {
    return loadUserByUsername(username)
  }
  
  UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User.withTransaction { status ->

      User user = User.findByUsername(username)
      // if the user does not exist
      if (!user) {
        // create user from LDAP
        user = User.createUserFromLdap(username)
        
        if (!user) throw new UsernameNotFoundException('User not in LDAP', username)
      }

      def authorities = user.authorities.collect { new GrantedAuthorityImpl(it.authority) }
      return new GrailsUser(user.username, user.password, user.enabled,
        !user.accountExpired, !user.passwordExpired,
        !user.accountLocked, authorities, user.id)
    }
  }
}
