package twidder

class Message {

  static belongsTo = [User]

  User author

  String content

  Date time

  static constraints = {
    content(blank:false, size:0..140)
  }
  
  String toString() {
    "${content} at ${time}"
  }
}
