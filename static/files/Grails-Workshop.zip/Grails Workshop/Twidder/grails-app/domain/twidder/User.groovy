package twidder
import ldap.LdapUser

/**
 * User domain class
 *
 * Extends SpringUser class from Spring Security Plugin
 * extended by LDAP operations and project attributes
 *
 * @author Dominik Schuermann
 */
class User extends SpringUser {
  
	static hasMany  = [messages:Message]

  /** User Real Name */
	String firstname
  String lastname

  /** eMail */
	String email


	static constraints = {
		firstname(blank: false)
    lastname(blank: false)
		email(nullable: false)
	}

  String toString() {
    "$firstname $lastname"
  }

  /**
   * creates new User by mapping the LDAPO class LdapUser
   *
   * @param String username the username for the creating user
   * @return returns the new user object
   */
  static createUserFromLdap(String username) {
    // search for the user in LDAP directory
    def ldapUser = LdapUser.find(directory: "tubs", filter: "(uid=${username})")

    // create the user
    def newUser = new User(
      username    : ldapUser.username,
      firstname   : ldapUser.firstname,
      lastname    : ldapUser.lastname,
      email       : ldapUser.email,
      password    : "usingcas", // not used because we use cas for authentication
      enabled     : true
    ).save(flush: true, failOnError: true)

    // give default role to new user
    def roleUser = SpringRole.findByAuthority('ROLE_USER')
    SpringUserSpringRole.create(newUser, roleUser, true)

    return newUser
  }

}