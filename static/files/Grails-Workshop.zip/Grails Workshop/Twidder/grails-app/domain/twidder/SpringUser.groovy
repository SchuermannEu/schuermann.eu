package twidder

class SpringUser {

	String username
	String password
	boolean enabled
	boolean accountExpired
	boolean accountLocked
	boolean passwordExpired

	static constraints = {
		username blank: false, unique: true
		password blank: false
	}

	static mapping = {
		password column: '`password`'
	}

	Set<SpringRole> getAuthorities() {
		SpringUserSpringRole.findAllBySpringUser(this).collect { it.springRole } as Set
	}
}
