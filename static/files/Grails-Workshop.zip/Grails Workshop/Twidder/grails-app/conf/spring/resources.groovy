
beans = {
  // using other Details Service for Spring Security to get user from ldap
  userDetailsService(MyUserDetailsService)
}