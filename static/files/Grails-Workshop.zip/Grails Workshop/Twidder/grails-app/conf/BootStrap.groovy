class BootStrap {

    def init = { servletContext ->
       def userRole = twidder.SpringRole.findByAuthority('ROLE_USER') ?: new twidder.SpringRole(authority : "ROLE_USER").save(failOnError: true)
    }
    def destroy = {
    }
}
